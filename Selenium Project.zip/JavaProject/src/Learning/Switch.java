package Learning;

public class Switch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int day=7;
		switch(day)
		{
		case 1:
		{
			System.out.println(" MonDay");
			break;
		}
		case 2:
		{
			System.out.println("TuesDay");
			break;
		}
		case 3:
		{
			System.out.println("WednesDay");
			break;
		}
		case 4:
		{
			System.out.println("ThursDay");
			break;
		}
		case 5:
		{
			System.out.println("FriDay");
			break;
		}
		case 6:
		{
			System.out.println("SaturDay");
			break;
		}
		case 7:
		{
			System.out.println("SunDay");
			break;
		}
		}
			
	}

}
