package Learning;

public class DataType {

	static int aa=89;
	public static void main(String[] args) {
		//If Any variable is declared and Value is initialized for same then low error will be displayed for that
		int a;
		
		//Boolean Data Type
		boolean b=true;
		boolean c=false;
		System.out.println(b);
		System.out.println(c);
		
		//char--'D','A'
		char d=109;
		//Here Value is getting printed as per the ASCII table
		System.out.println(d);
		//We can print single character here
		//can only store 1 place
		char d1='A';
		System.out.println(d1);
		//If you print string for char variable then Error  will be displayed
		//char d2='ASCII';
		//System.out.println(d2);
		
		//int
		int e=23;
		System.out.println(e);
		
		//Widening/Upcasting
		int f1=10;
		float g=f1;
		System.out.println(f1);

		//Narrowing/Explicit Type conversion
		double dd=100.04;
		long lg=(long)dd;
		System.out.println(lg);
		
		//Float
		float fk=100.09f;
		System.out.println(fk);
		
		//Double
		double Marks=201.5;
		System.out.println(Marks);
		
		//DataType 
		//"Integer" is a class in Java that provides a wrapper around the primitive "int" data type
		int x1=10;		
		Integer x2=100;		
		System.out.println(x1);		
		System.out.println(x2);
		
		//"Short" is a class in Java that provides a wrapper around the primitive "short" data type
		short y1=7878;
		Short y2=7898;		
		System.out.println(y1);
		System.out.println(y2);
		
		//static
		System.out.println(aa);
		
	}

}
