package Learning;

public class Ifexample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Normal If
		int a=100;
		if(a>10)
		{
			System.out.println("Value of a is greater than 100");
		}
		
		//If Else
		int b=90;
		if (b>50)
		{
			System.out.println("Value of b is greater than 50");
		}
		else
		{
			System.out.println("Value is b is less");
		}
		
		
		//Nested if Else
		int marks=98;
		if (marks>90)
		{
			System.out.println("OMG! You are Topper");
		}
		else if(marks > 80 && marks >=70)
		{
			System.out.println("You have received A Grade");
		}
		else if(marks > 70 && marks >=60)
		{
			System.out.println("You Got B Grade");
		}
		else
		{
			System.out.println("Don't Stream Netflix, Read Books");
		}
		
		//Nested if else 
		int mark=80;
		if (mark>95)
		{
			if (mark>90)
			{
				System.out.println("Too Good:");
			}
			else 
			{
				System.out.println("Keep it up:");
			}
		}
		else
			{
				System.out.println("Keep Learning And You will shine again");
			}
		}

}
