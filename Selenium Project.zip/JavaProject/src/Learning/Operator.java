package Learning;

import java.util.Scanner;

public class Operator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);

		int x1=10;
		
		int x2=20;
		
		int x3=x1+x2;

		System.out.println(x3);
		
		System.out.println(100+1000);
		
		System.out.println(100-1000);
		
		System.out.println(100*5);
		
		System.out.println(100/2);
		
		System.out.println(100/5.0);
		
		System.out.println(100<1000);
		
		System.out.println(100>1000);
		
		System.out.println(100<=100);
		
		System.out.println(100>=1000);
		
		
		//
		int a=10;
		
		//post increment , first use exiting value then increment the value
		System.out.println(a++);//10+1
		System.out.println(a);//11
		
		System.out.println(++a);//12
		System.out.println(a);
		
		System.out.println(a--);//12-1
		System.out.println(a);//11
		
		System.out.println(--a);//10
		System.out.println(a);//10
		
		//
		String str="Tell me Java";
		
		System.out.println(90+10+str);
		System.out.println(10+10+str+10+10);
		System.out.println(str+10+10);
	}
}
