package Assignment1;

public class Task4 {

	public static void main(String[] args) {

		System.out.println("Even numbers from 1-200:");
		for(int i=2;i<201;i++)
		{
			if (i%2==0)
			{
				System.out.println(i+" ");
			}
			
			
		}
		
	}

}
