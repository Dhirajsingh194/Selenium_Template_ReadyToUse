package Assignment1;

public class Task7 {

	public static void main(String[] args) {
		// a is Total number of row
		int i,j,a=6;
		for (i=0;i<a;i++)
		{
		for (j=0;j<=i;j++)
		{
		System.out.print("*");
				
		}
		System.out.println();
		}
		
	}

}

