package Assignment1;

public class Task5 {

	public static void main(String[] args) {

		System.out.println("odd numbers from 1-50:");
		for (int i=1;i<51;i++)
		{
			if(i%2!=0)
			{
				System.out.println(i);
			}
		}
	}

}
