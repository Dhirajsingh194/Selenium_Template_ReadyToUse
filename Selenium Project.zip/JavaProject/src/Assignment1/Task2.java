package Assignment1;

public class Task2 {

	public static void main(String[] args) {
		// Write a program to print the sum of below 5 numbers.
		//10,90.78,111,8989,7876

		int a=10;
		double b=90.78;
		int c=111;
		int d=8989;
		int e=7876;
		
		double sum=a+b+c+d+e;
		System.out.println(sum);
	}

}
