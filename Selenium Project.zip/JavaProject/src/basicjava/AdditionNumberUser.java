package basicjava;
import java.util.Scanner;
public class AdditionNumberUser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter First Number:-");
		int num1=scanner.nextInt();
		System.out.println("Enter Second Number:-");
		int num2=scanner.nextInt();	
		int num3=num1+num2;
		System.out.println("Addition of both Number:-"+num3);
	}
}
