package day3;

public class OperatorsDemo3 {


	public static void main(String[] args) {
		
		String name="Mukesh";
		
		System.out.println(10+10+20+name);
		
		System.out.println(name+10+10+20);
		
		System.out.println(10+78+name+20+100);
	
	}

}
