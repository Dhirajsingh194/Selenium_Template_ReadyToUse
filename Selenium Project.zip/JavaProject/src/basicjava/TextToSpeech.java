package basicjava;

import javax.sound.sampled.*;
import java.io.*;
import com.sun.speech.freetts.*;

public class TextToSpeech {

    public static void main(String[] args) {
        String text = "Hello, world!"; // text to convert to speech
        String outputFileName = "output.wav"; // output file name

        try {
            // create synthesizer
            FreeTTS synthesizer = new FreeTTS();

            // set output format
            AudioFormat af = new AudioFormat(22050, 16, 1, true, false);
            AudioFileFormat.Type fileType = AudioFileFormat.Type.WAVE;

            // create output file
            File outputFile = new File(outputFileName);

            // create audio output stream
            AudioInputStream audioInputStream = synthesizer.synthesize(text);
            AudioInputStream convertedAudioInputStream = AudioSystem.getAudioInputStream(af, audioInputStream);
            AudioSystem.write(convertedAudioInputStream, fileType, outputFile);

            // close streams
            convertedAudioInputStream.close();
            audioInputStream.close();
            synthesizer.shutdown();

            System.out.println("Text converted to audio and downloaded to " + outputFileName);

        } catch (IOException | UnsupportedAudioFileException | LineUnavailableException e) {
            e.printStackTrace();
        }
    }
}
