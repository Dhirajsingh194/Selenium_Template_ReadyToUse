package basicjava;

public class Solution {

    public static void main(String[] args) {
       System.out.print("if u are using System.out.print then next statement will be printed in same line");
       System.out.print("Print Statement without Print"); 
       
       System.out.println("Here we are using println then this statement will be printed in next line");
    }
}