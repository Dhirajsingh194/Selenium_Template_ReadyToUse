package day3;

public class OperatorsDemo2 {


	public static void main(String[] args) {
		
		int x1=100;
		
		System.out.println(x1++);
		
		System.out.println(x1);
		
		System.out.println("******************");
		
		int y1=100;
		
		System.out.println(++y1);
		
		System.out.println(y1);
	
	}

}
