package basicjava;

public class IfDemo {


	public static void main(String[] args) {
		
		System.out.println("Start");
		
		int age=20;
		
		if(age>21)
		{
			System.out.println("Eligible");
		}
		else 
		{
			System.out.println("Not eligible");
		}
	
		System.out.println("End");
		
		
	
	}

}
