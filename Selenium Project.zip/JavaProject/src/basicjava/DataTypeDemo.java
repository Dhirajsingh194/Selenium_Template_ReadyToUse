package day3;

public class DataTypeDemo {

	public static void main(String[] args) {
		
		// true and false
		boolean status = false;
		System.out.println(status);
		
		char c1 = 'a';
		System.out.println(c1);
		
		char c2=98;
		System.out.println(c2);
		
		//downcasting 
		byte marks=(byte)130;
		System.out.println(marks);
		
		short amount=32750;
		System.out.println(amount);
		
		int number=12345789;
		System.out.println(number);
		
		long phoneNumber=8986564545l;
		System.out.println(phoneNumber);
		
		float studentMarks=15.5f;
		System.out.println(studentMarks);
		
		double teachersMarks=20.5;
		System.out.println(teachersMarks);
		

		
		
	}

}
