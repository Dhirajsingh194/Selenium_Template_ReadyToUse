package basicjava;

import java.util.Scanner;

public class hundreddays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int b = 0;
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the number of Days you Work:");
		int a =scanner.nextInt();
		for(int i=0;i>=a;i++)
		{
			b=a*a;
		}
		System.out.println("Final"+b);
	}

}
