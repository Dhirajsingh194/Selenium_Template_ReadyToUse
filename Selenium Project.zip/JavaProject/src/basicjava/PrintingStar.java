package basicjava;

public class PrintingStar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i,j,a=6;
		for (i=0;i<a;i++)
		{
		for (j=0;j<=i;j++)
		{
		System.out.print("*");
				
		}
		System.out.println();
		}
		
	}

}
