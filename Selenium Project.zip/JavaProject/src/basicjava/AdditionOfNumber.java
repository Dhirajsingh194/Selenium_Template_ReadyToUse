package basicjava;

public class AdditionOfNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1=5;
		int num2=10;
		int result=num1+num2;
		System.out.println("Addition of two number is:-" + result);
	}

}
