
package assignment2;
import java.io.*;

class Geek
{
	String name;
	Geek(String name)
	{
		this.name=name;
		//System.out.println("Name"+name);
	}
	void display()
	{
		System.out.println("Name of employee is:"+name);
	}
}
public class Aa {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Geek g1=new Geek("Dhiraj");
		g1.display();
	}

}
