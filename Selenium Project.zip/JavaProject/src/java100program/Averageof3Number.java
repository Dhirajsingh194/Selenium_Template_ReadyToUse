//Total & Average of 3 Subjects
package java100program;

import java.util.Scanner;

public class Averageof3Number {

	public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	
	System.out.println("Enter Marks of Maths out of 100:");
	int a=scanner.nextInt();
	
	System.out.println("Enter Marks of Biology out of 100:");
	int b=scanner.nextInt();
	
	System.out.println("Enter Marks of Physics out of 100:");
	int c=scanner.nextInt();
	
	//calculate Total Marks
	int total=a+b+c;
	
	System.out.println("Total Mark of Student is:"+total+" Out of 300");
	
	//Calculate Average Marks
	int ave=total/3;
	
	//Displaying Average of 3 Marks
	System.out.println("Average of 3 Subjects are:"+ave);
	
	}

}
