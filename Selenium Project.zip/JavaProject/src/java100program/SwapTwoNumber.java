package java100program;

import java.util.Scanner;

public class SwapTwoNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		int a,b,temp = 0;
		
		System.out.println("Enter first Number: ");
		a=scanner.nextInt();
		
		System.out.println("Enter Second Number: ");
		b=scanner.nextInt();
		System.out.println("Before Swapping value of a is: " +a+ "And B is: "+b);

		//Storing Value of b in Temp
		temp=b;
		//Storing value of b in a
		b=a;
		//assigning value of b to a
		a=temp;
		
		System.out.println("After Swapping value of a is: " +a+ "And B is: "+b);
	}

}
