//Simple Interest = Principal x Rate x Time

package java100program;

import java.util.Scanner;

public class CalculateInterest {

	public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	
	System.out.println("Enter the Principal Amount:");
	double a=scanner.nextDouble();
	
	System.out.println("Enter the Rate of Interest:");
	double b=scanner.nextDouble();
	
	System.out.println("Enter the Time:");
	double c=scanner.nextDouble();
	
	double d=(a*b*c)/100;
	
	System.out.println("Simple Interest is:-"+d);
	
	}

}
