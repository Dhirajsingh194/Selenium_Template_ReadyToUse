package java100program;

import java.util.Scanner;

public class AverageOfTwoNumber {

	public static void main(String[] args) {
	
		//This is required for user input
		Scanner scanner=new Scanner(System.in);
		
		//Enter First Number
		System.out.println("Enter First Number");
		int a=scanner.nextInt();
		
		//Enter second Number
		System.out.println("Enter second Number");
		int b=scanner.nextInt();
		
		int c=(a+b)/2;
		
		System.out.println("Average of Two number is:-"+c);
	}

}
