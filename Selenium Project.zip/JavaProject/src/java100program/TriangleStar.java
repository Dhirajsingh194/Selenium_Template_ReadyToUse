package java100program;

public class TriangleStar {

	public static void main(String[] args) {
		// a is Total number of row
		/*int i,j,a=6;
		for (i=0;i<a;i++)
		{
		for (j=i;j<=i;j++)
		{
		System.out.print("*");
				
		}
		System.out.println();
		}*/		
	}

}
