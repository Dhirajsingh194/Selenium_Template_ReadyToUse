package java100program;

import java.util.Scanner;

public class AdditionOfTwoNumber {

	public static void main(String[] args) {
		
		//This is required for user input
		Scanner scanner=new Scanner(System.in);
		
		//Enter First Number
		System.out.println("Enter First Number");
		int a=scanner.nextInt();
		
		//Enter second Number
		System.out.println("Enter second Number");
		int b=scanner.nextInt();
		
		//Addition of a and b in third variable c
		int c=a+b;
		
		//Printing final output
		System.out.println("Addition of two Number is:-"+c);

	}

}
