package java100program;

import java.util.Scanner;

public class CircleArea {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		double pi=3.1456;
		System.out.println("Enter radius of circle");
		double ra=scanner.nextDouble();
		double radius=pi*ra*ra;
		System.out.println("Raduis of circle is:-"+radius);
		
		}

}
