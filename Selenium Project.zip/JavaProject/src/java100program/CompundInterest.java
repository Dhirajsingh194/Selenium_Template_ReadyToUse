package java100program;
import java.util.Scanner;
public class CompundInterest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Principle*(1+(rate / 100))^time – Principle
		double principle,rate,time,compound_interest;
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("Enter the Prinicipal Amount:");
		principle=scanner.nextInt();
		
		System.out.println("Enter the Rate:");
		rate=scanner.nextInt();
		
		System.out.println("Enter the Rate:");
		time=scanner.nextInt();
		
		
		//compund_interest =principal*(Math.pow(1+rate / 100),time)) – principal;
		compound_interest=principle*(Math.pow(1 + rate / 100), time)) - principle;
		System.out.println(compound_interest);
		
	}

}
