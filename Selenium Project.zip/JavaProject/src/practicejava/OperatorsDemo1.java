package practicejava;

import java.util.Scanner;

public class OperatorsDemo1 {


	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);

		int x1=100;
		
		int x2=200;
		
		int x3=x1+x2;

		System.out.println(x3);
		
		System.out.println(100+1000);
		
		System.out.println(100-1000);
		
		System.out.println(100*5);
		
		System.out.println(100/2);
		
		System.out.println(100/5.0);
		
		System.out.println(100<1000);
		
		System.out.println(100>1000);
		
		System.out.println(100<=100);
		
		System.out.println(100>=1000);
	
	
	}

}
