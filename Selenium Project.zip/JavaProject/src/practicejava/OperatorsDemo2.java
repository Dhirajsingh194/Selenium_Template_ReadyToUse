package practicejava;

public class OperatorsDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=100;
		
		//post increment , first use exiting vale then increment
		System.out.println(a++);
		System.out.println(a);
		
		System.out.println(++a);
		System.out.println(a);
		
		System.out.println(a--);
		System.out.println(a);
		
		System.out.println(--a);
		System.out.println(a);
	}

}
