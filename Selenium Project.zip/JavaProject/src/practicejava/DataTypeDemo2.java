package practicejava;

public class DataTypeDemo2 {

	public static void main(String[] args) {
		
		
		int x1=10;
		
		Integer x2=100;
		
		System.out.println(x1);
		
		System.out.println(x2);
		
		short y1=7878;
		
		Short y2=7898;
		
		System.out.println(y1);
		System.out.println(y2);
	
	}

}