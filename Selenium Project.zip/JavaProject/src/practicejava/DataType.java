package practicejava;

public class DataType {

	public static void main(String[] args) {
		// If u have declared the variable and not intilized the value then you
		//will get error
		boolean hyper = false;
		System.out.println(hyper);
		
		char c1 = 87;
		System.out.println(c1);
		
		//in char u can only store 1 place
		char c11='a';
		System.out.println(c11);
		
		//output for this coming as "", this is nothing but ascii value 
		//When number is provided to char then it will display corresponding 
		//value for same
		char c111=34;
		System.out.println(c111);
		
		
		//downcasting 
				byte marks=(byte)130;
				System.out.println(marks);
							
				short amount=32750;
				System.out.println(amount);
				
				int cu=67687989;
				System.out.println(cu);
				
				//The literal 782637846378318 of type int is out of range 
				//Even define is long this error is coming
				/*long pnum=782637846378318;
				System.out.println(pnum);*/
				
				//after number use l then it will treat as long
				long phoneNumber=8986564545l;
				System.out.println(phoneNumber);
				
				int number=12345789;
				System.out.println(number);
				
				//For float number provide number and end with f
				//then it will consider as float
			
				float studentMarks=15.5f;
				System.out.println(studentMarks);
				
				double teachersMarks=20.5;
				System.out.println(teachersMarks);
		
	}

}
