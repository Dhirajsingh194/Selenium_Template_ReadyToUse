package practicejava;

public class OperatorsDemo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="Java but How";
		
		System.out.println(10+10+str);
		System.out.println(10+10+str+10+10);
		System.out.println(str+10+10);
	}

}
