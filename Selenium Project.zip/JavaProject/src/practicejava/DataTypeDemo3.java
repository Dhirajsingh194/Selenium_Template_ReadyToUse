package practicejava;

public class DataTypeDemo3 {

	static int x;
	
	public static void main(String[] args) {
		
		System.out.println(x);
	
	}

}