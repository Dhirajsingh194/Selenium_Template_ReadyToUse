package selewebpack;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Navigation;
import org.openqa.selenium.chrome.ChromeDriver;

public class NavigationCommands {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.co.in/");
		driver.get("https://twitter.com/");
		driver.get("https://linkedin.com/");
		
		//On Top on web Navigation are present like Forward,Backward,refresh button
		Navigation nav=driver.navigate();
		nav.back();
		
		// Line 17,18 and Line 20 will have same behaviour
		driver.navigate().back();
		Thread.sleep(1000);
		driver.navigate().back();
		driver.navigate().forward();
		driver.navigate().forward();
		driver.navigate().refresh();
		driver.quit();
		
	}

}
