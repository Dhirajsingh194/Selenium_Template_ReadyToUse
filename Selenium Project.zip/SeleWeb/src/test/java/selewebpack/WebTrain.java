package selewebpack;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebTrain {

	public static void main(String[] args) {
		// Start the Chrome session
		ChromeDriver driver=new ChromeDriver();
		
		//This is Parent Driver for all chrome,Firefox and Safari Webdriver
		//This is mainly used for cross browser testing
		//WebDriver driver1=new ChromeDriver();
		
		//Open Google.com URL
		driver.get("https://www.google.co.in/");
		
		//Fetch Title on goggle.com Site and Store in title parameter
		String title=driver.getTitle();
		System.out.println("Title of this page is:" + title);
		System.out.println("Site URL of Current Page is:"+driver.getCurrentUrl());
		
		//String src=driver.getPageSource();
		//System.out.println("Below is the page:"+src);
		
		//This close all tabs and window
		//driver.quit();
		
		//This will closed only particular tab only
		//driver.close();
	}

}
