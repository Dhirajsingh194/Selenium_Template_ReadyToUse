package selewebpack;

import org.openqa.selenium.chrome.ChromeDriver;

public class WebTrain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://www.google.co.in/");
		//This close all tabs and window
		driver.quit();
		
		
		//This will closed only particular tab only
		driver.close();
	}

}
