package selewebpack;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class NavigationCommands2 {

	/*Difference between navigate().to vs .get()*/
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver=new ChromeDriver();
		driver.navigate().to("https://www.google.co.in/");
		driver.get("https://www.google.co.in/");
		//driver.navigate().to
	}

}
